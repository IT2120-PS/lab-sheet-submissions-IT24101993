setwd("C:\\Users\\Shaheen Nazar\\Desktop\\Lab9_IT24101993")
set.seed(123)  # For reproducible results
baking_times <- rnorm(25, mean = 45, sd = 2)
print("Generated baking times:")
print(baking_times)
test_result <- t.test(baking_times, mu = 46, alternative = "less")
print("One-Sample T-Test Results:")
print(test_result)
test_statistic <- test_result$statistic
p_value <- test_result$p.value
confidence_interval <- test_result$conf.int
cat("\nDetailed Results:\n")
cat("Test Statistic (t):", test_statistic, "\n")
cat("P-value:", p_value, "\n")
cat("95% Confidence Interval:", confidence_interval, "\n")
if (p_value < 0.05) {
  conclusion <- "Since p-value is less than 0.05, we REJECT H0 at 5% level of significance."
  interpretation <- "There is sufficient evidence to conclude that the average baking time is less than 46 minutes."
} else {
  conclusion <- "Since p-value is greater than or equal to 0.05, we DO NOT REJECT H0 at 5% level of significance."
  interpretation <- "There is insufficient evidence to conclude that the average baking time is less than 46 minutes."
}
cat("\nConclusion:\n")
cat(conclusion, "\n")
cat(interpretation, "\n")
print("One-Sample T-Test Results:")
print(test_result)
test_statistic <- test_result$statistic
p_value <- test_result$p.value
setwd("C:\\Users\\hP\\OneDrive - Sri Lanka Institute of Information Technology\\Desktop\\IT24102169 Lab 9")
set.seed(123)  # For reproducible results
baking_times <- rnorm(25, mean = 45, sd = 2)
print("Generated baking times:")
print(baking_times)
test_result <- t.test(baking_times, mu = 46, alternative = "less")
print("One-Sample T-Test Results:")
print(test_result)
test_statistic <- test_result$statistic
p_value <- test_result$p.value
confidence_interval <- test_result$conf.int
cat("\nDetailed Results:\n")
cat("Test Statistic (t):", test_statistic, "\n")
cat("P-value:", p_value, "\n")
cat("95% Confidence Interval:", confidence_interval, "\n")
if (p_value < 0.05) {
  conclusion <- "Since p-value is less than 0.05, we REJECT H0 at 5% level of significance."
  interpretation <- "There is sufficient evidence to conclude that the average baking time is less than 46 minutes."
} else {
  conclusion <- "Since p-value is greater than or equal to 0.05, we DO NOT REJECT H0 at 5% level of significance."
  interpretation <- "There is insufficient evidence to conclude that the average baking time is less than 46 minutes."
}
cat("\nConclusion:\n")
cat(conclusion, "\n")
cat(interpretation, "\n")
cat("\nSummary Statistics:\n")
cat("Sample Mean:", mean(baking_times), "\n")
cat("Sample Standard Deviation:", sd(baking_times), "\n")
cat("Sample Size:", length(baking_times), "\n")
