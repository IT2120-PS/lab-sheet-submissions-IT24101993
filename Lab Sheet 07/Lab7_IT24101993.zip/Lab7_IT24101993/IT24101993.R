
setwd("C:\\Users\\Shaheen Nazar\\Desktop\\Lab7_IT24101993")
prob <- punif(25, min = 0, max = 40, lower.tail = TRUE) - punif(10, min = 0, max = 40, lower.tail = TRUE)
prob
prob <- pexp(2, rate = 1/3, lower.tail = TRUE)
prob
prob_i <- 1 - pnorm(130, mean = 100, sd = 15, lower.tail = TRUE)
prob_i
iq_score <- qnorm(0.95, mean = 100, sd = 15, lower.tail = TRUE)
iq_score
cat("Question 1 - Probability train arrives between 8:10 and 8:25:\n")
prob1 <- punif(25, min = 0, max = 40, lower.tail = TRUE) - punif(10, min = 0, max = 40, lower.tail = TRUE)
cat("P(10 ≤ X ≤ 25) =", prob1, "\n\n")
cat("Question 2 - Probability update takes at most 2 hours:\n")
prob2 <- pexp(2, rate = 1/3, lower.tail = TRUE)
cat("P(X ≤ 2) =", prob2, "\n\n")
cat("Question 3 - IQ Scores:\n")
# Part i
prob3_i <- 1 - pnorm(130, mean = 100, sd = 15, lower.tail = TRUE)
cat("i) P(X > 130) =", prob3_i, "\n")
# Part ii
iq_95 <- qnorm(0.95, mean = 100, sd = 15, lower.tail = TRUE)
cat("ii) 95th percentile IQ score =", iq_95, "\n")
